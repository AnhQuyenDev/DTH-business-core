<?php

namespace App\Filament\Resources\LandingPageResource\Pages;

use App\Filament\Resources\LandingPageResource;
use App\Models\Marketing\FormTemplate;
use App\Models\Sales\Service;
use App\Models\Sales\ServicePackage;
use App\Services\Marketing\MarketingCampaignServiceScopeService;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Validation\ValidationException;

class EditLandingPage extends EditRecord
{
    protected static string $resource =
        LandingPageResource::class;

    private ?int $personalFormTemplateId = null;

    private ?int $businessFormTemplateId = null;

    /** @var array<int, int> */
    private array $servicePackageIds = [];

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }

    protected function mutateFormDataBeforeFill(
        array $data
    ): array {
        $data['personal_form_template_id'] =
            $this->record
                ->forms()
                ->where('form_type', 'personal')
                ->value('form_template_id');

        $data['business_form_template_id'] =
            $this->record
                ->forms()
                ->where('form_type', 'business')
                ->value('form_template_id');

        $data['service_package_ids'] = $this->record
            ->servicePackages()
            ->pluck('service_packages.id')
            ->map(fn (mixed $id): int => (int) $id)
            ->values()
            ->all();

        return $data;
    }

    protected function mutateFormDataBeforeSave(
        array $data
    ): array {
        $this->personalFormTemplateId = filled(
            $data['personal_form_template_id'] ?? null
        )
            ? (int) $data['personal_form_template_id']
            : null;

        $this->businessFormTemplateId = filled(
            $data['business_form_template_id'] ?? null
        )
            ? (int) $data['business_form_template_id']
            : null;

        $this->servicePackageIds = collect(
            $data['service_package_ids'] ?? []
        )
            ->filter(fn (mixed $id): bool => filled($id))
            ->map(fn (mixed $id): int => (int) $id)
            ->unique()
            ->values()
            ->all();

        unset(
            $data['personal_form_template_id'],
            $data['business_form_template_id'],
            $data['service_package_ids']
        );

        $this->validateServiceContext($data);
        $this->validateBeforePublish($data);

        return $data;
    }

    protected function afterSave(): void
    {
        $this->syncForm(
            'personal',
            $this->personalFormTemplateId,
            0
        );

        $this->syncForm(
            'business',
            $this->businessFormTemplateId,
            1
        );

        $this->record->servicePackages()->sync(
            $this->servicePackageIds
        );
    }

    private function syncForm(
        string $type,
        ?int $templateId,
        int $sortOrder
    ): void {
        if ($templateId === null) {
            $this->record
                ->forms()
                ->where('form_type', $type)
                ->delete();

            return;
        }

        $this->record->forms()->updateOrCreate(
            ['form_type' => $type],
            [
                'form_template_id' => $templateId,
                'display_mode' => 'embedded',
                'position_key' => 'end',
                'is_default' => true,
                'sort_order' => $sortOrder,
                'status' => 'active',
            ]
        );
    }


    private function validateServiceContext(array $data): void
    {
        $serviceId = filled($data['service_id'] ?? null)
            ? (int) $data['service_id']
            : null;

        $marketingCampaignId = filled($data['marketing_campaign_id'] ?? null)
            ? (int) $data['marketing_campaign_id']
            : null;

        app(MarketingCampaignServiceScopeService::class)
            ->assertLandingPageServiceAllowed(
                $marketingCampaignId,
                $serviceId,
            );

        if ($serviceId === null) {
            if ($this->servicePackageIds !== []) {
                throw ValidationException::withMessages([
                    'service_id' => 'Vui lòng chọn dịch vụ trước khi chọn gói.',
                ]);
            }

            return;
        }

        $validService = Service::query()
            ->whereKey($serviceId)
            ->where('status', 'active')
            ->exists();

        if (! $validService) {
            throw ValidationException::withMessages([
                'service_id' => 'Dịch vụ được chọn không hoạt động hoặc không tồn tại.',
            ]);
        }

        if ($this->servicePackageIds === []) {
            return;
        }

        $validPackageCount = ServicePackage::query()
            ->whereIn('id', $this->servicePackageIds)
            ->where('service_id', $serviceId)
            ->where('status', 'active')
            ->count();

        if ($validPackageCount !== count($this->servicePackageIds)) {
            throw ValidationException::withMessages([
                'service_package_ids' => 'Có gói không thuộc dịch vụ đã chọn hoặc không còn hoạt động.',
            ]);
        }
    }

    private function formUsesServiceInterest(?int $templateId): bool
    {
        if ($templateId === null) {
            return false;
        }

        return FormTemplate::query()
            ->whereKey($templateId)
            ->whereHas(
                'fields',
                fn ($query) => $query->whereIn('contact_mapping', [
                    'lead.service_interest',
                    'personal.service_interest',
                    'business.service_interest',
                ])
            )
            ->exists();
    }

    private function validateBeforePublish(
        array $data
    ): void {
        if (($data['status'] ?? null) !== 'published') {
            return;
        }

        $errors = [];

        if (
            empty($data['campaign_id']) &&
            empty($data['marketing_campaign_id'])
        ) {
            $errors['campaign_id'] =
                __('notification.landing_page_requires_campaign');
        }

        if ($this->personalFormTemplateId === null) {
            $errors['personal_form_template_id'] =
                'Vui lòng chọn Form cá nhân.';
        }

        if ($this->businessFormTemplateId === null) {
            $errors['business_form_template_id'] =
                'Vui lòng chọn Form doanh nghiệp.';
        }

        $needsServiceContext = $this->formUsesServiceInterest(
            $this->personalFormTemplateId
        ) || $this->formUsesServiceInterest(
            $this->businessFormTemplateId
        );

        if ($needsServiceContext && empty($data['service_id'])) {
            $errors['service_id'] =
                'Landing Page có trường Dịch vụ quan tâm nên phải chọn Dịch vụ chính.';
        }

        if ($errors !== []) {
            throw ValidationException::withMessages($errors);
        }
    }
}
