<?php

namespace Dth\HumanResource\Filament\Resources\DepartmentResource\Pages;

use Dth\HumanResource\Filament\Resources\DepartmentResource;
use Dth\HumanResource\Filament\Support\HumanResourcePageUi;
use Dth\HumanResource\Support\UiText;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Contracts\Support\Htmlable;

class CreateDepartment extends CreateRecord
{
    protected static string $resource = DepartmentResource::class;

    public function getTitle(): string|Htmlable
    {
        return HumanResourcePageUi::title(
            UiText::get('pages.department_create.title', 'Create department'),
            'department',
            'violet',
        );
    }
}
