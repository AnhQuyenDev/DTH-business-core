<?php

namespace Dth\HumanResource\Filament\Resources\PositionResource\Pages;

use Dth\HumanResource\Filament\Resources\PositionResource;
use Dth\HumanResource\Filament\Support\HumanResourcePageUi;
use Dth\HumanResource\Support\UiText;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Contracts\Support\Htmlable;

class CreatePosition extends CreateRecord
{
    protected static string $resource = PositionResource::class;

    public function getTitle(): string|Htmlable
    {
        return HumanResourcePageUi::title(
            UiText::get('pages.position_create.title', 'Create job title'),
            'position',
            'amber',
        );
    }
}
